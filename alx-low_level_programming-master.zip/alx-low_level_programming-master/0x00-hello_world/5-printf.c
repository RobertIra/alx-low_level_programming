#include <stdio.h>
/**
 * main - A program that print a line using the printf function
 * Return: 0 (success)
 */
int main(void)
{
printf("with proper grammar, but the outcome is a piece of art,\n");
return (0);
}
