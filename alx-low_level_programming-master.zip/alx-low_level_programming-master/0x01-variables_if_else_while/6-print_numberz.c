#include <stdio.h>

/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
int i;
for (i = 0; i < 10; i++)
{
putchar(i + '0'); /* print the digit character */
}
putchar('\n'); /* print a newline character */
return (0);
}

