#include "main.h"

/**
 * print_alphabet - Prints the lowercase alphabet from a to z
 */

void print_alphabet(void)
{
	char x;

	for (x = 'a'; x <= 'z'; x++)
	{
		_putchar(x);
	}
	_putchar('\n');
}
